# M VASTRA — Free Website

A static, mobile-responsive luxury men's fashion storefront.

## Run locally
Open `index.html` in a browser.

## Publish for free
1. Create a free GitHub account.
2. Create a new public repository named `mvastra`.
3. Upload all files in this folder.
4. Import the repository into Vercel and deploy.
5. Vercel will give you a free public URL.

## Important
- Replace the generated concept image in `assets/mvastra-hero.png` with your actual product/model photos when ready.
- Update the Instagram URL in `index.html` to the brand's real Instagram profile.
- WhatsApp ordering is already set to 9665151554.
