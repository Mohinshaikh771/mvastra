const products = [
  ["Classic White Shirt","₹500","p1"],["Black Solid Shirt","₹500","p2"],["Olive Green Shirt","₹500","p3"],["Striped Shirt","₹500","p4"],
  ["Black Check Shirt","₹500","p5"],["Beige Shirt","₹500","p6"],["Navy Blue Shirt","₹500","p7"],["White Linen Shirt","₹500","p8"]
];
const cart = [];
const grid = document.getElementById("products");

grid.innerHTML = products.map((p,i)=>`
  <article class="card">
    <div class="pic"><div class="${p[2]}"></div></div>
    <div class="info">
      <h3>${p[0]}</h3><div class="price">${p[1]}</div>
      <div class="sizes">${["S","M","L","XL"].map(s=>`<button onclick="chooseSize(this)">${s}</button>`).join("")}</div>
      <button class="order" onclick="addToCart(${i})">Add to Cart</button>
    </div>
  </article>`).join("");

function chooseSize(btn){
  [...btn.parentElement.children].forEach(x=>x.classList.remove("active"));
  btn.classList.add("active");
}
function addToCart(i){
  cart.push({name:products[i][0], price:500, size:"M"});
  renderCart(); toggleCart(true);
}
function renderCart(){
  document.getElementById("cartCount").textContent=cart.length;
  const items=document.getElementById("cartItems");
  items.innerHTML=cart.length ? cart.map((x,i)=>`<div class="cart-item"><span>${x.name}<br><small>Size: ${x.size}</small></span><b>₹${x.price}</b></div>`).join("") : "<p style='color:#888;padding:25px 0'>Your cart is empty.</p>";
  document.getElementById("cartTotal").textContent="₹"+cart.reduce((a,x)=>a+x.price,0);
}
function toggleCart(force){
  const c=document.getElementById("cart"),o=document.getElementById("overlay");
  const open=force===true ? true : !c.classList.contains("open");
  c.classList.toggle("open",open); o.classList.toggle("show",open);
}
function checkoutWhatsApp(){
  if(!cart.length){ alert("Please add a product first."); return; }
  const lines=cart.map(x=>`• ${x.name} — ₹${x.price} — Size ${x.size}`);
  const total=cart.reduce((a,x)=>a+x.price,0);
  const msg=`Hello M VASTRA! I want to place an order:%0A%0A${encodeURIComponent(lines.join("\n"))}%0A%0ATotal: ₹${total}%0A%0APlease share payment and delivery details.`;
  window.open("https://wa.me/919665151554?text="+msg,"_blank");
}
renderCart();
